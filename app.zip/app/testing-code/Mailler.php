<?php 

namespace core;

class Mailler {
    
}