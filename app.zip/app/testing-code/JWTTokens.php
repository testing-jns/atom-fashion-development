<?php 

namespace core;

class JWTTokens {
    
}