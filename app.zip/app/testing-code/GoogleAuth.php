<?php 

namespace core;

class GoogleAuth {
    
}