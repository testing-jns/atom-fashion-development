<?php 

namespace core;

class GoogleRecaptcha {

}