<?php 

namespace core;
// Setelah router dan sebelum controllers
class Middleware {
    // Authentication
    // Authorization
    // Validasi input
    // Sanitasi input
    // Response handler
    // Data logger
    // etc...

}