<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Warning : 405 Method not Allowed</title>
</head>
<body>
    <h1>405 : Your Method not Allowed!</h1>
</body>
</html>