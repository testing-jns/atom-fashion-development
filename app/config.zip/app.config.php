<?php

define("ROOT_DIR", "./");
define("PATH_APP", __DIR__ . "/../");
define("BASE_URL", ($_SERVER["REQUEST_SCHEME"] ?? "http") . "://" . $_SERVER["HTTP_HOST"] . "/");

