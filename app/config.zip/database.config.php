<?php 

define("DB_DBMS", "mysql");
define("DB_HOST", "192.168.1.111");
define("DB_USER", "jns23");
define("DB_PASS", "jns123");
define("DB_NAME", "atom_fashion");

define("DB_FILE_LOGS", "./database.log");
// define("DB_FILE_LOGS", "/var/www/kelompok2_atom-fashion/main/public/database.log");


?>
