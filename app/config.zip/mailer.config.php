<?php 

// PHP Mailer
define("PM_HOST", "smtp.gmail.com");
define("PM_NAME", "Atom Fashion");
define("PM_USER", "noreply.atomfashion@gmail.com");
define("PM_PASS", "jiykheollvdbxcyv");


define("PM_FILE_LOGS", "./mailer.log");