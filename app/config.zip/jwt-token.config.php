<?php

define("JWT_KEY", "6B.z=+,DrN;a-h;@U_DZqB.t(&{g#gMp-4PuST?ZY(Ju+&g&Xt8i3HdkTkmZY35TA216!_YzVW8D,Y.ti=)pN?BRSTz,F8K@Gx0R");


