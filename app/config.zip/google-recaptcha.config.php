<?php

define("GOOLE_RECAPTCHA_ENDPOINT", "https://www.google.com/recaptcha/api/siteverify");
define("GOOLE_RECAPTCHA_SITE_KEY", "6LdFGFQmAAAAALwYiveDWpyw_Z8vStTwiexbvLV9");
define("GOOLE_RECAPTCHA_SECRET_KEY", "6LdFGFQmAAAAAK2V_p6WpBVGLpComtiOQUoTlhKE");

