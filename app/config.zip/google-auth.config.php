<?php

define("GOOGLE_CLIENT_ID", "992422471620-k255vs3p0pp6uuei74l2sk8ekigu9c6a.apps.googleusercontent.com");
define("GOOGLE_CLIENT_SECRET", "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");
define("GOOGLE_AUTH_REDIRECT_URI_FOR_SIGNUP", "http://localhost/signup");
define("GOOGLE_AUTH_REDIRECT_URI_FOR_LOGIN", "http://localhost/login");

