<?php 

ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

// Error karna beda versi php
// Local : PHP version 8.2.7 
// Server: PHP version 7.3

// echo phpinfo();

var_dump($_SERVER);